#include <string>
#include <iostream>
using namespace std;
#include "Author.h"
#include "Paper.h"

Paper:: Paper()
{
    head = NULL;
    name = " ";
}
Paper:: Paper(  string namex )
{
    name = namex;
}
Paper::~Paper()
{
    AuthorNode* current = head;

    while(current != NULL)
    {
        AuthorNode* next = current->next;
        delete current;
        current = next;
    }
    head = NULL;
}
Paper::   Paper( const Paper& paperToCopy )
{
   if (paperToCopy.head == NULL)
      head = NULL;
   else {

      head = new AuthorNode;
      head->a = paperToCopy.head->a;

      AuthorNode *newPtr = head;

      for (AuthorNode *origPtr = paperToCopy.head->next;
                     origPtr != NULL;
                     origPtr = origPtr->next){
         newPtr->next = new AuthorNode;
         newPtr = newPtr->next;
         newPtr->a = origPtr->a;
      }
      newPtr->next = NULL;
   }
}


void Paper:: operator=( const Paper& right )
{
     if(right.head == NULL)
        head = NULL;
    else
    {
        head  = new AuthorNode;
        head->a = right.head->a;
        AuthorNode *newNode = head;
        AuthorNode *original = right.head->next;
        while(newNode != NULL)
        {
            newNode->next = new AuthorNode;
            newNode = newNode ->next;
            newNode->a = original->a;
        }
        newNode->next = NULL;
    }
}
string Paper:: getPaperName()
{
    return name;
}
void Paper:: setPaperName(string nameNew)
{
     name = nameNew;
}
bool Paper:: isAuthorExist(int authorId)
{
    AuthorNode* current = head;
    bool state = false;
    if(current == NULL)
    {
        state = false;
    }
    else {
        while(current != NULL)
        {
            if(current->a.getID() == authorId)
            {
                state = true;
            }
            current = current->next;
        }
    }
    return state;

}
string Paper:: isAuthorName(int authorId)
{
    AuthorNode* current = head;
    string name = " ";
    if(current == NULL)
    {
        cout<< "--EMPTY--" << endl;
    }
    else {
        while(current != NULL)
        {
            if(current->a.getID() == authorId)
            {
                name = current->a.getName();
                break;
            }
            current = current->next;
        }
    }
    return name;
}
bool Paper:: addAuthor( const int id, const string name )
{
    AuthorNode *temp = new AuthorNode;
    (temp->a).setName(name);
    (temp->a).setId(id);
    AuthorNode* current = head;
    bool state = false;
    bool added = false;
    if(current == NULL)
    {
        temp->next = head;
        head = temp;
        added = true;
    }
    else
    {
        while(current != NULL)
        {
            if(current->a.getName() == name)
            {
                state = true;
                break;
            }
            current = current-> next;
        }
        if(state)
        {
            added = false;
        }
        else
        {
            current = head;
            while(current->next != NULL)
            {
                current = current-> next;
            }
            temp-> next = current-> next;
            current->next = temp;
            added = true;
        }
    }
    return added;
}
bool Paper:: removeAuthor ( const int id )
{
    AuthorNode* current = head;
    bool removed = false;
    if(head == NULL)
    {
        removed = false;
    }
    else
    {
        AuthorNode* found = findAuthor(id);
        if(found != NULL)
        {
            if(head == found)
            {
                AuthorNode* temp = head;
                head = head->next;
                delete temp;
                removed = true;
            }
            else
            {
                AuthorNode* prev = current;
                while(current != found)
                {
                    prev = current;
                    current = current->next;
                }
                prev->next = current->next;
                delete current;
                removed = true;
            }
        }
        else
            removed = false;
    }
    return removed;
}
void Paper:: displayAuthors()
{
    AuthorNode* current = head;
    if(current == NULL)
    {
        cout<< "EMPTY" << endl;
    }
    while( current != NULL)
    {
        cout<<"Author:  " << current ->a.getID() << " "<< current->a.getName()<< endl;
        current = current-> next;
    }
}
Paper:: AuthorNode*Paper:: findAuthor(int id)
{
    AuthorNode* searched = NULL;
    AuthorNode* current = head;

    if(current == NULL)
        return searched;
    else
    {
        Author x = current ->a;
        while( current != NULL)
        {
            if(x.getID() == id)
            {
                searched = current;
                break;
            }
            current = current->next;
            x = current->a;
        }
    }
    return searched;
}
