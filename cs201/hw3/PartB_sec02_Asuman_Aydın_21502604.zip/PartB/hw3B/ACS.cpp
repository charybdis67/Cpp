#include <string>
#include <iostream>
using namespace std;
#include "Track.h"
#include "Paper.h"
#include "ACS.h"


ACS::ACS()
{
    head = NULL;
    trackCount = 0;
}
ACS::~ACS()
{
    Node* current = head;

    while(current != NULL)
    {
        Node* next = current->next;
        delete current;
        current = next;
    }
    head = NULL;
}
ACS:: ACS( const ACS& systemToCopy )
{

    if(systemToCopy.head == NULL)
        head = NULL;
    else
    {
        head  = new Node;
        head->t = systemToCopy.head->t;
        Node *newNode = head;
        Node *original = systemToCopy.head->next;
        while(newNode != NULL)
        {
            newNode->next = new Node;
            newNode = newNode ->next;
            newNode->t = original->t;
        }
        newNode->next = NULL;
    }
}
void ACS:: operator=( const ACS& right )
{
    if(right.head == NULL)
        head = NULL;
    else
    {
        head  = new Node;
        head->t = right.head->t;
        Node *newNode = head;
        Node *original = right.head->next;
        while(newNode != NULL)
        {
            newNode->next = new Node;
            newNode = newNode ->next;
            newNode->t = original->t;
        }
        newNode->next = NULL;
    }
}
void ACS:: addTrack( string trackName )
{
    Node *temp = new Node;
    (temp->t).setTrackName(trackName);
    temp->t.addPaper(" ");
    Node* current = head;
    bool state = false;
    if(current == NULL)
    {
        temp->next = head;
        head = temp;

    }
    else
    {
        while(current != NULL)
        {
            if(current->t.getTrackName() == trackName)
            {
                state = true;
                break;
            }
            current = current-> next;
        }
        if(state)
        {
            cout<< "There is such a track!"<< endl;
        }
        else
        {
            current = head;
            while(current->next != NULL)
            {
                current = current-> next;
            }
            temp-> next = current-> next;
            current->next = temp;
        }
    }

}
void ACS:: removeTrack( string trackName )
{
    Node* current = head;
    Node* temp = NULL;
    bool found = false;
    if(head == NULL)
    {
        cout<< "--EMPTY--" << endl;
    }
    else
    {
        while(current!= NULL)
        {
            if(current->t.getTrackName() == trackName)
            {
                found = true;
                temp = current;
                break;
            }
            else
                current = current->next;
        }
        current = head;
        if(found == true)
        {
            if(head == temp)
            {
                Node* temp2 = head;
                head = head->next;
                delete temp2;
            }
            else
            {
                Node* prev = current;
                while(current != temp)
                {
                    prev = current;
                    current = current->next;
                }
                prev->next = current->next;
                delete current;
                cout<< "removed" << endl;
            }
        }
        else
            cout<< "there is no such a track" << endl;
    }
}
void ACS:: displayAllTracks()
{
    Node* current = head;
    if(current == NULL)
    {
        cout<< "EMPTY" << endl;
    }
    while( current != NULL)
    {
        cout<<"TrackName  " << current ->t.getTrackName() << endl;
        current = current-> next;
    }
}
void ACS:: addPaper( string trackName, string paperName )
{
    Node *temp = new Node;
    (temp->t).setTrackName(trackName);
    Paper newPaper;
    newPaper.setPaperName(paperName);
    bool exists = temp->t.addPaper(newPaper.getPaperName());
    Node* current = head;
    bool state = false;

    if(current == NULL)
    {
        temp->next = head;
        head = temp;
    }
    else
    {
        while(current != NULL)
        {
            if( current->t.getTrackName() == trackName && exists != true)
            {
                state = true;
                break;
            }
            current = current-> next;
        }
        if(state)
        {
            cout<< "There is such a paper" << endl;
        }
        else
        {
            current = head;
            while(current->next != NULL)
            {
                current = current-> next;
            }
            temp-> next = current-> next;
            current->next = temp;
            cout<< "added" << endl;
        }
    }

}
void ACS:: removePaper( string trackName, string paperName )
{
    Node* current = head;
    Node* temp = NULL;
    bool found = false;
    if(head == NULL)
    {

        cout<< "--EMPTY--"<< endl;
    }
    else
    {
        while(current!= NULL)
        {
            if(current->t.getTrackName() == trackName && current->t.isPaperName(paperName) == true)
            {
                found = true;
                temp = current;
                break;
            }
            else
                current = current->next;
        }
        current = head;
        if(found == true)
        {
            if(head == temp)
            {
                Node* temp2 = head;
                head = head->next;
                delete temp2;
            }
            else
            {
                Node* prev = current;
                while(current != temp)
                {
                    prev = current;
                    current = current->next;
                }
                prev->next = current->next;
                delete current;
                cout<< "removed" << endl;

            }
        }
        else
            cout<< " not removed " << endl;
    }
}
void ACS:: addAuthor( string trackName, string paperName, int authorID, string authorName )
{
    Node *temp = new Node;
    (temp->t).setTrackName(trackName);
    Paper newPaper;
    newPaper.setPaperName(paperName);
    bool authorexists = newPaper.isAuthorExist(authorID);
    bool exists = temp->t.isPaperName(paperName);
    Node* current = head;
    bool state = false;

    if(current == NULL)
    {
        temp->next = head;
        head = temp;
    }
    else
    {
        while(current != NULL)
        {
            if( current->t.getTrackName() != trackName && exists != true && authorexists != true)
            {
                state = true;
                break;
            }
            current = current-> next;
        }
        if(state)
        {
            cout<< "There is such track or a paper or author" << endl;
        }
        else
        {

            current = head;
            while(current->next != NULL)
            {
                current = current-> next;
            }
            temp-> next = current-> next;
            current->next = temp;
            temp->t.addPaper(newPaper.getPaperName());
            newPaper.addAuthor(authorID,authorName);
            cout<< "added" << endl;
        }
    }

}
void ACS:: removeAuthor(string trackName, string paperNameZ, int authorID )
{
    Node* current = head;
    Node* temp = NULL;
    Paper newPaper;
    newPaper.setPaperName(paperNameZ);
    cout<< " girdi 1" << endl;
    bool authorexists = newPaper.isAuthorExist(authorID);
    bool found = false;
    if(head == NULL)
    {

        cout<< "--EMPTY--" << endl;
    }
    else
    {
        while(current!= NULL)
        {
            cout<< " girdi 4" << endl;
            if(current->t.getTrackName() == trackName && current->t.isPaperName(paperNameZ) == true && authorexists == true)
            {
                found = true;
                temp = current;
                break;
            }
            else
                current = current->next;
        }
        current = head;
        if(found == true)
        {
            if(head == temp)
            {
                Node* temp2 = head;
                head = head->next;
                temp2->t.removePaper(newPaper.getPaperName());
                newPaper.removeAuthor(authorID);
                delete temp2;
            }
            else
            {
                Node* prev = current;
                while(current != temp)
                {
                    prev = current;
                    current = current->next;
                }
                prev->next = current->next;
                current->t.removePaper(newPaper.getPaperName());
                newPaper.removeAuthor(authorID);
                if(current)
                {
                    delete current;
                }
                cout<< "removed" << endl;

            }
        }
        else
            cout<< " not removed " << endl;
    }
}
void ACS:: displayTrack( string trackName )
{
    Node* track = findTrack(trackName);
    if(track != NULL)
    {
        cout<< "Track is " << track->t.getTrackName()<< endl;
    }
}
void ACS:: displayAuthor( int authorID )
{
    Node* current = head;
    int i = 1;
    if(current == NULL)
    {
        cout<< "--EMPTY--" << endl;
    }
    else
    {
         while(current != NULL)
        {
            cout<< current->t.getTrackName() <<  "(for the " << i << "st track)" << endl;
            current->t.getPapername(authorID);
            current = current->next;
        }
    }
}
ACS:: Node* ACS:: findTrack(string trackName)
{
    Node* searched = NULL;
    Node* current = head;

    if(current == NULL)
        return searched;
    else
    {
        Track x = current ->t;
        while( current != NULL)
        {
            if(x.getTrackName() == trackName)
            {
                searched = current;
                break;
            }
            current = current->next;
            x = current->t;
        }
    }
    return searched;
}
