#ifndef __PAPER_H
#define __PAPER_H
#include <string>
using namespace std;
#include "Author.h"
class Paper
{
public:
    Paper();
    Paper( const string name );
    ~Paper();
    Paper( const Paper& paperToCopy );
    void operator=( const Paper& right );
    string getPaperName();
    void setPaperName(string name);
    bool addAuthor( const int id, const string name );
    bool removeAuthor ( const int id );
    bool isAuthorExist(int id);
    string isAuthorName(int id);
    void displayAuthors();
private:
    struct AuthorNode
    {
        Author a;
        AuthorNode* next;
    };
    AuthorNode *head;
    string name;
    AuthorNode* findAuthor(int id);
};
#endif
