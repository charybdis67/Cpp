#include "Paper.h"
#include "Track.h"
#include <string>
#include <iostream>
using namespace std;

Track::Track(string name)
{
    trackName = name;
    head = NULL;
}
Track::~Track ()
{
    PaperNode* current = head;

    while(current != NULL)
    {
        PaperNode* next = current->next;
        delete current;
        current = next;
    }
    head = NULL;
}

Track::Track (const Track &trackToCopy)
{

    if(trackToCopy.head == NULL)
        head = NULL;
    else
    {
        head  = new PaperNode;
        head->p = trackToCopy.head->p;
        PaperNode *newNode = head;
        PaperNode *original = trackToCopy.head->next;
        while(newNode != NULL)
        {
            newNode->next = new PaperNode;
            newNode = newNode ->next;
            newNode->p = original->p;
        }
        newNode->next = NULL;
    }
}
void Track::operator=(const Track &right)
{

    if(right.head == NULL)
        head = NULL;
    else
    {
        head  = new PaperNode;
        head->p = right.head->p;
        PaperNode *newNode = head;
        PaperNode *original = right.head->next;
        while(newNode != NULL)
        {
            newNode->next = new PaperNode;
            newNode = newNode ->next;
            newNode->p = original->p;
        }
        newNode->next = NULL;
    }

}
string Track:: getTrackName()
{
    return trackName;
}
void Track:: setTrackName(string setName)
{
    trackName = setName;
}
bool Track:: isPaperName(string paperName)
{
    PaperNode* current = head;
    bool state = false;
    if(current == NULL)
    {
        state = false;
    }
    else {
        while(current != NULL)
        {
            if(current->p.getPaperName() == paperName)
            {
                state = true;
            }
            current = current->next;
        }
    }
    return state;

}
bool Track:: addPaper(string paperName)
{
    PaperNode *temp = new PaperNode;
    (temp->p).setPaperName(paperName);
    PaperNode* current = head;
    bool state = false;
    bool added = false;
    if(current == NULL)
    {
        temp->next = head;
        head = temp;
        added = true;
    }
    else
    {
        while(current != NULL)
        {
            if(current->p.getPaperName() == paperName)
            {
                state = true;
                break;
            }
            current = current-> next;
        }
        if(state)
        {
            added = false;
        }
        else
        {
            current = head;
            while(current->next != NULL)
            {
                current = current-> next;
            }
            temp-> next = current-> next;
            current->next = temp;
            added = true;
        }
    }
    return added;
}

bool Track:: removePaper(string paperNameY)
{
    PaperNode* current = head;
    PaperNode* temp = NULL;
    bool removed = false;
    bool found = false;
    if(head == NULL)
    {
        removed = false;
    }
    else
    {
        while(current!= NULL)
        {
            if(current->p.getPaperName() == paperNameY)
            {
                found = true;
                temp = current;
                break;
            }
            else
                current = current->next;
        }
        current = head;
        if(found == true)
        {
            if(head == temp)
            {
                PaperNode* temp2 = head;
                head = head->next;
                delete temp2;
                removed = true;
            }
            else
            {
                PaperNode* prev = current;
                while(current != temp)
                {
                    prev = current;
                    current = current->next;
                }
                prev->next = current->next;
                delete current;
                removed = true;
            }
        }
        else
            removed = false;
    }
    return removed;
}

void Track:: displayPapers()
{
    PaperNode* current = head;
    if(current == NULL)
    {
        cout<< "--EMPTY--" << endl;
    }
    while( current != NULL)
    {
        cout<<"Paper:  " << current ->p.getPaperName() << endl;
        current = current-> next;
    }
}
void Track:: getPapername(int authorId)
{
    PaperNode* current = head;
    string name = " ";
    bool returned = false;
    int y = 1;
    if(current == NULL)
    {
        cout<< "--EMPTY--" << endl;
        returned = false;
    }
    else
    {
        while(current != NULL)
        {
            if(current->p.isAuthorExist(authorId) == true){
                cout<< authorId << "," <<  current->p.isAuthorName(authorId) << endl;
                cout<< "\n" << current->p.getPaperName() << "(for the " << y << "st paper in " << endl;
            }
                y++;
            current = current->next;
        }
        returned = true;
    }
}
