#include "Paper.h"
#include "ACS.h"
#include "Author.h"
#include "Track.h"
#include <iostream>
using namespace std;

int main()
{
    Author author;
    author.setId(20);
    author.setName("asuman");
    cout <<author.getID() << endl;
    cout<< author.getName() << endl;

    Paper paper;
    paper.displayAuthors();

    paper.addAuthor(20,"asuman");
    paper.displayAuthors();

//    paper.removeAuthor(20);
//    paper.displayAuthors();
    paper.setPaperName("asuman");
    Track track;
    track.setTrackName("aydin");
    track.addPaper(paper.getPaperName());
    track.displayPapers();
//    track.removePaper(paper.getPaperName());
   track.displayPapers();
    ACS acs;
    acs.addTrack(track.getTrackName());
    acs.displayAllTracks();
//    acs.removeTrack(track.getTrackName());
    acs.displayAllTracks();
    acs.addPaper(track.getTrackName(),paper.getPaperName());
    acs.removePaper(track.getTrackName(),paper.getPaperName());
    acs.addAuthor(track.getTrackName(),paper.getPaperName(),author.getID(),author.getName());
    acs.removeAuthor(track.getTrackName(),paper.getPaperName(),author.getID());
    acs.displayAuthor(author.getID());
    return 0;

}
