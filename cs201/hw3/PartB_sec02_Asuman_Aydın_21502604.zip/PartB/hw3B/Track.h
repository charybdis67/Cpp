
#include "Paper.h"
#ifndef __TRACK_H
#define __TRACK_H
#include <string>
using namespace std;
class Track
{
public:
    Track(const string tname = "");
    ~Track ();
    Track (const Track &trackToCopy);
    void operator=(const Track &right);
    string getTrackName();
    void  setTrackName(string setName);
    bool addPaper(string paperName);
    bool removePaper(string paperName);
    void displayPapers();
    bool isPaperName(string paperName);
    void getPapername(int authorId);

    private:

    struct PaperNode
    {
        Paper p;
        PaperNode* next;
    };
    PaperNode *head;
    string trackName;
};
#endif
