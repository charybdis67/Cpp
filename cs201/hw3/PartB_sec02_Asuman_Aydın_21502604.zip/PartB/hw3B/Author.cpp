#include <string>
using namespace std;
#include "Author.h"

Author::Author()
{
    name = " ";
    id = 0;
}
Author:: Author( int idTemp,  string nameTemp)
{
    name = nameTemp;
    id = idTemp;
}
int Author:: getID()
{
    return id;
}
string Author::getName()
{
    return name;
}
void Author:: setName(string nameNew)
{
    name = nameNew;
}
void Author:: setId(int idNew)
{
    id = idNew;
}
