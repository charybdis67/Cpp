
/*
*	Title : Algorithm Efficiency and Sorting
*	Author : Asuman Aydin
*   ID : 21502604
*	Section : 01
*	Assignment : 1
*	Description : Source file of Sorting codes
*/

#include <iostream>
using namespace std;
#include "sorting.h"
#include <string>
#include <stdlib.h>
#include <ctime>
#include <cmath>

const int MAX_SIZE = 21001;
void swapNumbers(int& first, int& last, int& moveCount)
{
	int temp = first;
	first = last;
	last = temp;
	//move count increase as swaped
	moveCount += 3;
}
//insertion sort
void  insertionSort(int* arr, int size, int& compCount, int& moveCount)
{
	for (int i = 1; i < size; ++i)
	{
		for (; (i > 0) && (arr[i - 1] > arr[i]); compCount++, i--)
		{
			int temp = arr[i];
			arr[i] = arr[i - 1];
			arr[i - 1] = temp;
			moveCount += 3;
		}
		compCount++; // to see f it will enter the for statement, it makes comparison in for
	}
}
void quickSort(int* arr, int f, int l, int& compCount, int& moveCount)
{
	int pivotIndex;
	if (f < l)
	{
		compCount++; //comparison in if statement
		partitionQuick(arr, f, l, pivotIndex, compCount, moveCount);
		quickSort(arr, f, pivotIndex - 1, compCount, moveCount);
		quickSort(arr, pivotIndex + 1, l, compCount, moveCount);
	}
}
void partitionQuick(int* arr, int first, int last, int& pivotIndex, int& compCount, int& moveCount)
{
	pivotIndex = arr[first];
	int lastS1 = first;
	int first1 = first + 1;
	moveCount += 3; //3 assignment
	for (; first1 <= last; first1++, compCount++)
	{
		if (arr[first1] < pivotIndex)
		{
			++lastS1;
			compCount++;
			swapNumbers(arr[first1], arr[lastS1], moveCount);
		}
	}
	swapNumbers(arr[first], arr[lastS1], moveCount);
	pivotIndex = lastS1;
	moveCount++;
}
//hybridSort
void  hybridSort(int* arr, int size, int& compCount, int& moveCount)
{
    int f = 0;
    int l = size -1;
	if(l -f +1 <= 10)
    {
        cout<< "girdi" << endl;
        insertionSort(arr,l-f+1,compCount,moveCount);
    }
    else
    {
        int pivotIndex;
        partitionQuick(arr, f, l, pivotIndex, compCount, moveCount);
		quickSort(arr, f, pivotIndex - 1, compCount, moveCount);
		quickSort(arr, pivotIndex + 1, l, compCount, moveCount);
    }
}
void printArray(int* arr, int n)
{
	cout << "output of array" << endl;
	cout << "---------------" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
	cout << "---------------" << endl;

}
void performanceAnalysis()
{
	int compCount, moveCount = 0;

	//ARRAY OF 2000
	int* arrHybrid = new int[1500];
	int* arrInsert = new int[1500];
	int* arrQuick = new int[1500];
	for (int i = 0; i < 1500; i++)
	{
		arrHybrid[i] = rand() % 2000 + 1;
		arrQuick[i] = arrHybrid[i];
		arrInsert[i] = arrHybrid[i];
	}
	//ARRAY OF 3000
	int* arrHybrid2 = new int[3000];
	int* arrInsert2 = new int[3000];
	int* arrQuick2 = new int[3000];
	for (int i = 0; i < 3000; i++)
	{
		arrHybrid2[i] = rand() % 2000 + 1;
		arrQuick2[i] = arrHybrid2[i];
		arrInsert2[i] = arrHybrid2[i];
	}
	//ARRAY OF 4500
	int* arrHybrid3 = new int[4500];
	int* arrInsert3 = new int[4500];
	int* arrQuick3 = new int[4500];
	for (int i = 0; i < 4500; i++)
	{
		arrHybrid3[i] = rand() % 2000 + 1;
		arrQuick3[i] = arrHybrid3[i];
		arrInsert3[i] = arrHybrid3[i];
	}
	//ARRAY OF 6000
	int* arrHybrid4 = new int[6000];
	int* arrInsert4 = new int[6000];
	int* arrQuick4 = new int[6000];
	for (int i = 0; i < 6000; i++)
	{
		arrHybrid4[i] = rand() % 2000 + 1;
		arrQuick4[i] = arrHybrid4[i];
		arrInsert4[i] = arrHybrid4[i];
	}
	//ARRAY OF 7500
	int* arrHybrid5 = new int[7500];
	int* arrInsert5 = new int[7500];
	int* arrQuick5 = new int[7500];
	for (int i = 0; i < 7500; i++)
	{
		arrHybrid5[i] = rand() % 2000 + 1;
		arrQuick5[i] = arrHybrid5[i];
		arrInsert5[i] = arrHybrid5[i];
	}
	//ARRAY OF 9000
	int* arrHybrid6 = new int[9000];
	int* arrInsert6 = new int[9000];
	int* arrQuick6 = new int[9000];
	for (int i = 0; i < 9000; i++)
	{
		arrHybrid6[i] = rand() % 2000 + 1;
		arrQuick6[i] = arrHybrid6[i];
		arrInsert6[i] = arrHybrid6[i];
	}
	//ARRAY OF 10500
	int* arrHybrid7 = new int[10500];
	int* arrInsert7 = new int[10500];
	int* arrQuick7 = new int[10500];
	for (int i = 0; i < 10500; i++)
	{
		arrHybrid7[i] = rand() % 2000 + 1;
		arrQuick7[i] = arrHybrid7[i];
		arrInsert7[i] = arrHybrid7[i];
	}
	//ARRAY OF 12000
	int* arrHybrid8 = new int[12000];
	int* arrInsert8 = new int[12000];
	int* arrQuick8 = new int[12000];
	for (int i = 0; i < 12000; i++)
	{
		arrHybrid8[i] = rand() % 2000 + 1;
		arrQuick8[i] = arrHybrid8[i];
		arrInsert8[i] = arrHybrid8[i];
	}
	//ARRAY OF 13500
	int* arrHybrid9 = new int[13500];
	int* arrInsert9 = new int[13500];
	int* arrQuick9 = new int[13500];
	for (int i = 0; i < 13500; i++)
	{
		arrHybrid9[i] = rand() % 2000 + 1;
		arrQuick9[i] = arrHybrid9[i];
		arrInsert9[i] = arrHybrid9[i];
	}
	//ARRAY OF 15000
	int* arrHybrid10 = new int[15000];
	int* arrInsert10 = new int[15000];
	int* arrQuick10 = new int[15000];
	for (int i = 0; i < 15000; i++)
	{
		arrHybrid10[i] = rand() % 2000 + 1;
		arrQuick10[i] = arrHybrid10[i];
		arrInsert10[i] = arrHybrid10[i];
	}
	cout << "-----------------------------------------------------" << endl;
	cout << "Part c - Time analysis of Quick Sort " << endl;
	cout << "Array Size Time Elapsed compCount moveCount" << endl;
	compCount = 0;
	moveCount = 0;
	for (int i = 1500; i <= 15000; i += 1500)
	{
		compCount = 0;
		moveCount = 0;
		double duration;
		clock_t startTime = clock();
		if (i == 1500)
		{
			quickSort(arrQuick, 0, i - 1, compCount, moveCount);
		}
		else if (i == 3000)
		{
			quickSort(arrQuick2, 0, i - 1, compCount, moveCount);
		}
		else if (i == 4500)
		{
			quickSort(arrQuick3, 0, i - 1, compCount, moveCount);
		}
		else if (i == 6000)
		{
			quickSort(arrQuick4, 0, i - 1, compCount, moveCount);
		}
		else if (i == 7500)
		{
			quickSort(arrQuick5, 0, i - 1, compCount, moveCount);
		}
		else if (i == 9000)
		{
			quickSort(arrQuick6, 0, i - 1, compCount, moveCount);
		}
		else if (i == 10500)
		{
			quickSort(arrQuick7, 0, i - 1, compCount, moveCount);
		}
		else if (i == 12000)
		{
			quickSort(arrQuick8, 0, i - 1, compCount, moveCount);
		}
		else if(i ==  13500)
        {
            quickSort(arrQuick8, 0, i - 1, compCount, moveCount);
        }
        else if(i = 15000)
        {
            quickSort(arrQuick8, 0, i - 1, compCount, moveCount);
        }
		duration = 1000 * double(clock() - startTime) / (CLOCKS_PER_SEC);
		cout << i << "       " << duration << " ms        " << compCount << "  " << moveCount << endl;
		duration = 0;
	}
	cout << "  " << endl;
	cout << "-----------------------------------------------------" << endl;
	cout << "Part c - Time analysis of Insert Sort " << endl;
	cout << "Array Size Time Elapsed compCount moveCount" << endl;
	compCount = 0;
	moveCount = 0;
	for (int i = 1500; i <= 15000; i += 1500)
	{
		compCount = 0;
		moveCount = 0;
		double duration;
		clock_t startTime = clock();
		if (i == 1500)
		{
			insertionSort(arrInsert, i, compCount, moveCount);
		}
		else if (i == 3000)
		{
			insertionSort(arrInsert2, i, compCount, moveCount);
		}
		else if (i == 4500)
		{
			insertionSort(arrInsert3, i, compCount, moveCount);
		}
		else if (i == 6000)
		{
			insertionSort(arrInsert4, i, compCount, moveCount);
		}
		else if (i == 7500)
		{
			insertionSort(arrInsert4, i, compCount, moveCount);
		}
		else if (i == 9000)
		{
			insertionSort(arrInsert4, i, compCount, moveCount);
		}
		else if (i == 10500)
		{
			insertionSort(arrInsert4, i, compCount, moveCount);
		}
		else if (i == 12000)
		{
			insertionSort(arrInsert4, i, compCount, moveCount);
		}
		else if(i ==  13500)
        {
			insertionSort(arrInsert4, i, compCount, moveCount);
        }
        else if(i = 15000)
        {
			insertionSort(arrInsert4, i, compCount, moveCount);
        }
		duration = 1000 * double(clock() - startTime) / (CLOCKS_PER_SEC);
		cout << i << "       " << duration << " ms        " << compCount << "  " << moveCount << endl;
		duration = 0;
	}

	cout << "-----------------------------------------------------" << endl;
	cout << "Part c - Time analysis of Hybrid Sort " << endl;
	cout << "Array Size Time Elapsed compCount moveCount" << endl;
	for (int i = 1500; i <= 15000; i += 1500)
	{
		compCount = 0;
		moveCount = 0;
		double duration;
		clock_t startTime = clock();
		if (i == 1500)
		{
			hybridSort(arrHybrid, i, compCount, moveCount);
		}
		else if (i == 3000)
		{
			hybridSort(arrHybrid2, i, compCount, moveCount);
		}
		else if (i == 4500)
		{
			hybridSort(arrHybrid3, i, compCount, moveCount);
		}
		else if (i == 6000)
		{
			hybridSort(arrHybrid4, i, compCount, moveCount);
		}
		else if (i == 7500)
		{
			hybridSort(arrHybrid5, i, compCount, moveCount);
		}
		else if (i == 9000)
		{
			hybridSort(arrHybrid6, i, compCount, moveCount);
		}
		else if (i == 10500)
		{
			hybridSort(arrHybrid7, i, compCount, moveCount);
		}
		else if (i == 12000)
		{
			hybridSort(arrHybrid8, i, compCount, moveCount);
		}
		else if(i == 13500)
        {
			hybridSort(arrHybrid8, i, compCount, moveCount);
        }
        else if(i = 15000)
        {
			hybridSort(arrHybrid8, i, compCount, moveCount);
        }
		duration = 1000 * double(clock() - startTime) / (CLOCKS_PER_SEC);
		cout << i << "       " << duration << " ms        " << compCount << "  " << moveCount << endl;
		duration = 0;
	}
	cout << "  " << endl;
}


