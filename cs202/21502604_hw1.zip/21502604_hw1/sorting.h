
/*
*	Title : Algorithm Efficiency and Sorting
*	Author : Asuman Aydin
*   ID : 21502604
*	Section : 01
*	Assignment : 1
*	Description : Source file of Sorting codes
*/

#include <iostream>
using namespace std;
#include <string>
#include <stdlib.h>
#include <ctime>
#include <cmath>

void swapNumbers(int& first, int& last, int& moveCount);
void quickSort(int* arr, int first, int last, int& compCount, int& moveCount);
void partitionQuick(int* arr, int first, int last, int& pivotIndex, int& compCount, int& moveCount);
void  insertionSort(int* arr, int size, int& compCount, int& moveCount);
void  hybridSort(int* arr, int size, int& compCount, int& moveCount);
void printArray(int* arr, int n);
void performanceAnalysis();
