
/*
*	Title : Algorithm Efficiency and Sorting
*	Author : Asuman Aydin
*   ID : 21502604
*	Section : 01
*	Assignment : 1
*	Description : main
*/


#include "sorting.h"
#include <iostream>
using namespace std;
#include <string>

int main()
{
    int compCount = 0;
    int moveCount = 0;
    int mainArray[12] = {22, 11, 6, 7, 30, 2, 27, 24, 9, 1, 20, 17};

    cout << " " << endl;
    cout<< "Quick Sort" << endl;
    quickSort(mainArray,0,11,compCount,moveCount);
    compCount = 0;
     moveCount = 0;
    printArray(mainArray,12);

    int mainArray2[12] = {22, 11, 6, 7, 30, 2, 27, 24, 9, 1, 20, 17};
    insertionSort(mainArray2,12,compCount,moveCount);
    compCount = 0;
     moveCount = 0;
    cout << " " << endl;
    cout<< "Insertion Sort " << endl;
    printArray(mainArray2,12);

    cout << " " << endl;
    cout<< "Hybrid Sort" << endl;
    int mainArray3[12] = {22, 11, 6, 7, 30, 2, 27, 24, 9, 1, 20, 17};
    hybridSort(mainArray3,12,compCount,moveCount);
    compCount = 0;
    moveCount = 0;
    printArray(mainArray3,12);


    performanceAnalysis();
    return 0;

}


