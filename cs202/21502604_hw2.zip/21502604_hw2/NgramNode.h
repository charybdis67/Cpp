/**
* Title : Binary Search Trees
* Author : ASUMAN AYDIN
* ID: 21502604
* Section : 1
* Assignment : 2
* Description : HEADER FILE FOR N-GRAM NODE
*/
#include <iostream>
using namespace std;
#ifndef __NGRAMNODE_H
#define __NGRAMNODE_H

class NgramNode
{
private:
    string ngram;
    int countNgram;
    NgramNode* leftPointer;
    NgramNode* rightPointer;
public:
    NgramNode();
    NgramNode(const string& ngramString);
    NgramNode(const string& ngramString, NgramNode* left, NgramNode* right);
    int getCount();
    void setCount(int countNgramNew);
    string getStringNgram();
    friend class NgramTree;
};
#endif
