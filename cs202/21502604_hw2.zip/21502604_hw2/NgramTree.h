/**
* Title : Binary Search Trees
* Author : ASUMAN AYDIN
* ID: 21502604
* Section : 1
* Assignment : 2
* Description : HEADER FILE FOR N-GRAM TREE
*/
#include <iostream>
#include <stdlib.h>
using namespace std;
#include <cmath>
#include "NgramNode.h"
#ifndef __NGRAMTREE_H
#define __NGRAMTREE_H

class NgramTree
{
public :
    NgramTree ();
    NgramTree(const string& ngram);
    NgramTree(const string& ngram, NgramTree& leftPoint, NgramTree& rightPoint);
    NgramTree(const NgramTree& newTree);
    ~ NgramTree ();
    void addNgram (string ngram );
    int getTotalNgramCount ();
    void printNgramFrequencies ();
    bool isComplete ();
    bool isFull ();
    void generateTree (string fileName, int n);
private :
    NgramNode* root;

    void copyConstructor(NgramNode* root, NgramNode*& other) const
    {
        if(root != NULL)
        {
            other = new NgramNode(root->ngram, NULL, NULL);
            copyConstructor(root->leftPointer, other->leftPointer);
            copyConstructor(root->rightPointer,other->rightPointer);
        }
        else
        {
            other = NULL;
        }
    }
    void destructor(NgramNode*& root)
    {
        if(root != NULL)
        {
            destructor(root->leftPointer);
            destructor(root->rightPointer);
            delete root;
            root = NULL;
        }
    }
    void insertNgramNode(NgramNode*& nodeptr,const string& ngramString)
    {
        if(nodeptr == NULL)
        {
            nodeptr = new NgramNode(ngramString,NULL,NULL);
        }
        else if(ngramString < nodeptr->getStringNgram())
        {
            insertNgramNode(nodeptr->leftPointer,ngramString);
        }
        else if(ngramString > nodeptr->getStringNgram())
        {
            insertNgramNode(nodeptr->rightPointer,ngramString);
        }
        else if(ngramString == nodeptr->ngram)
        {
            //
            int n = nodeptr->countNgram;
            n++;
            nodeptr->setCount(n);
        }
    }
    void countTotalNgram(NgramNode* nodeptr,int& countNgram)
    {
        if(nodeptr != NULL)
        {
            countNgram++;
            countTotalNgram(nodeptr->leftPointer,countNgram);
            countTotalNgram(nodeptr->rightPointer,countNgram);
        }
    }
    void printTree(NgramNode* nodeptr)
    {
        if(nodeptr != NULL)
        {
            printTree(nodeptr->leftPointer);
            cout<< nodeptr->getStringNgram() << " appears " << nodeptr->getCount() << " time(s)" << endl;
            printTree(nodeptr->rightPointer);
        }
    }
    void isFullAux(NgramNode* nodeptr,bool& isFull )
    {
        if(nodeptr!= NULL)
        {
            isFullAux(nodeptr->leftPointer,isFull);
            if(nodeptr != NULL && nodeptr->leftPointer != NULL && nodeptr->rightPointer != NULL)
            {
                isFull = true;
            }
            else
            {
                isFull = false;
            }
            isFullAux(nodeptr->rightPointer,isFull);
        }
    }
    int getHeightHelper(NgramNode* treePtr) const
    {
        if(treePtr ==   NULL)
        {
            return 0;
        }
        else
        {
            return 1+ max(getHeightHelper(treePtr->leftPointer), getHeightHelper(treePtr->rightPointer));
        }
    }
    void getNodeCountInLevel(NgramNode* ptr, int level, int &changeLevel, int &countNode)
    {
        if(changeLevel >= 0 && ptr != NULL)
        {
            getNodeCountInLevel(ptr->leftPointer, level,--changeLevel,++countNode);
            getNodeCountInLevel(ptr->rightPointer, level,--changeLevel,++countNode);
        }
    }
    bool isCompleteAux(NgramNode* nodeptr)
    {
        if(root == NULL)
        {
            return true;
        }
        else
        {
            int countNode = 0;
            int level = getHeightHelper(nodeptr) + 1;
            getNodeCountInLevel(nodeptr,level,level,countNode);
            if(countNode == pow(2,level)-1)
            {
                return false;
            }
        }
    }
};
#endif
