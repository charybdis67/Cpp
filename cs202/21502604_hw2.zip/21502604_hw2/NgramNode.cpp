/**
* Title : Binary Search Trees
* Author : ASUMAN AYDIN
* ID: 21502604
* Section : 1
* Assignment : 2
* Description : SOURCE FILE FOR N-GRAM NODE
*/
#include "NgramNode.h"
using namespace std;
#include "iostream"

NgramNode:: NgramNode()
{
    ngram = "";
    countNgram = 0;
    leftPointer = NULL;
    rightPointer = NULL;
}
NgramNode:: NgramNode( const string& ngramString)
{
    ngram = "";
    countNgram = 1;
    leftPointer = NULL;
    rightPointer = NULL;
}
NgramNode:: NgramNode(const string& ngramString, NgramNode* left, NgramNode* right)
{
    countNgram = 1;
    ngram = ngramString;
    leftPointer = left;
    rightPointer = right;
}
int NgramNode:: getCount()
{
    return countNgram;
}
void NgramNode:: setCount(int ngram)
{
    countNgram = ngram;
}
string NgramNode:: getStringNgram()
{
    return this->ngram;
}

