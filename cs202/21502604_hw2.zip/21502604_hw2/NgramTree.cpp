/**
* Title : Binary Search Trees
* Author : ASUMAN AYDIN
* ID: 21502604
* Section : 1
* Assignment : 2
* Description : SOURCE FILE FOR N-GRAM TREE
*/
#include "NgramTree.h"
#include "NgramNode.h"
#include <iostream>
#include <stdlib.h>
#include <fstream>
using namespace std;

NgramTree::NgramTree ()
{
    root = NULL;
}
NgramTree::NgramTree(const string& ngram)
{
    root = new NgramNode(ngram);
}
NgramTree::NgramTree(const string& ngram, NgramTree& leftPoint, NgramTree& rightPoint)
{
    root = new NgramNode(ngram,leftPoint.root,rightPoint.root);
}
NgramTree::NgramTree(const NgramTree& newTree)
{
    copyConstructor(newTree.root, root);
}
NgramTree::~ NgramTree()
{
    destructor(root);
}
void NgramTree:: addNgram (string ngram)
{
    insertNgramNode(root,ngram);
}
int NgramTree:: getTotalNgramCount()
{
    int countNgram = 0;
    if(root != NULL)
    {
        countTotalNgram(root,countNgram);
    }
    return countNgram;
}
void NgramTree:: printNgramFrequencies()
{
    printTree(root);
}
bool NgramTree:: isComplete ()
{
    int countGram = 0;
    countTotalNgram(root,countGram);
    return isCompleteAux(root);
}
bool NgramTree:: isFull ()
{
    bool isFull = false;
    if(root == NULL)
    {
        return isFull = true;
    }
    isFullAux(root,isFull);
    return isFull;
}
void NgramTree:: generateTree ( string fileName, int n)
{
    string words;
    ifstream file;
    file.open(fileName);
    if(file.is_open())
    {
        while ( file >> words)
        {
            if(words.size() < n){}
            else if(words.size() == n)
            {
                addNgram(words);
            }
            else if(words.size() > n)
            {
                for(int i = 0; i + n-1 <= words.size(); i++)
                {
                    if(i == 0)
                    {
                        string ngram = words.substr(i,i+n);
                        addNgram(ngram);
                    }
                    else
                    {
                        string ngram = words.substr(i,n);
                        if(ngram.size() == n)
                        {
                            addNgram(ngram);
                        }
                    }
                }
            }
        }
        file.close();
    }
    else
    {
        cout<< "unable to open a file" << endl;
    }
}


